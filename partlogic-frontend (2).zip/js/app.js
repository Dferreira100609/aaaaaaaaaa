/* ==========================================================================
   PartLogic — Interface (SPA em JS puro, roteamento por hash)
   Nenhum dado de demonstração: todo conteúdo vem de js/api.js.
   ========================================================================== */

const app = document.getElementById("app");
const modal = document.getElementById("modal");
const modalTitulo = document.getElementById("modal-titulo");
const modalCorpo = document.getElementById("modal-corpo");

/* ------------------------------------------------------------- utilidades -- */
const esc = (v) =>
  String(v ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );

const formatarValor = (n) =>
  typeof n === "number"
    ? n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })
    : "—";

const formatarData = (iso) => (iso ? new Date(iso).toLocaleDateString("pt-BR") : "—");

function avisar(mensagem, tipo = "erro") {
  const el = document.createElement("div");
  el.className = `aviso ${tipo === "ok" ? "ok" : ""}`;
  el.textContent = mensagem;
  document.getElementById("avisos").appendChild(el);
  setTimeout(() => el.remove(), 4000);
}

function abrirModal(titulo, html) {
  modalTitulo.textContent = titulo;
  modalCorpo.innerHTML = html;
  modal.hidden = false;
}
function fecharModal() {
  modal.hidden = true;
  modalCorpo.innerHTML = "";
}
modal.addEventListener("click", (e) => {
  if (e.target === modal) fecharModal();
});

const TIPOS_VEICULO = ["Carro", "Moto", "Caminhão", "Ônibus", "Van", "Outro"];
const COMBUSTIVEIS = ["Flex", "Gasolina", "Diesel", "Etanol", "Híbrido", "Elétrico"];
const STATUS_MANUTENCAO = ["Próxima", "Agendada", "Realizada", "Atrasada"];

const seloResultado = (r) =>
  ({
    COMPATIVEL: '<span class="selo selo-compativel">✓ Compatível</span>',
    INCOMPATIVEL: '<span class="selo selo-incompativel">✕ Não compatível</span>',
    VERIFICAR: '<span class="selo selo-verificar">⚠ Não confirmada</span>',
  })[r] || '<span class="selo">—</span>';

const estadoVazio = (titulo, texto, acao = "") => `
  <div class="estado">
    <h3>${esc(titulo)}</h3>
    <p>${esc(texto)}</p>
    ${acao}
  </div>`;

const carregando = () => `
  <div class="grade grade-2">
    <div class="esqueleto"></div><div class="esqueleto"></div>
    <div class="esqueleto"></div><div class="esqueleto"></div>
  </div>`;

const marca = () => '<div class="marca">Part<span>Logic</span></div>';

/* ------------------------------------------------------------------ shell -- */
const MENU = [
  ["#/dashboard", "Painel"],
  ["#/verificar", "Consultar peça"],
  ["#/veiculos", "Meus veículos"],
  ["#/manutencao", "Manutenção"],
  ["#/historico", "Histórico"],
  ["#/perfil", "Perfil"],
  ["#/configuracoes", "Configurações"],
];

function shell(rotaAtual, conteudo) {
  const links = (classe) =>
    MENU.map(
      ([href, rotulo]) =>
        `<a href="${href}" class="${href === rotaAtual ? "ativo" : ""}">${rotulo}</a>`,
    ).join("");

  return `
  <div class="app">
    <aside class="lateral">
      ${marca()}
      <nav class="nav">${links()}</nav>
      <div class="lateral-rodape">
        <button class="btn btn-fantasma btn-sm" data-acao="sair">Sair da conta</button>
      </div>
    </aside>
    <div>
      <div class="topo-mobile">
        ${marca()}
        <button class="btn btn-fantasma btn-sm" data-acao="sair">Sair</button>
      </div>
      <main class="conteudo">${conteudo}</main>
    </div>
  </div>
  <nav class="nav-inferior">${links()}</nav>`;
}

const cabecalho = (titulo, subtitulo, acoes = "") => `
  <header class="topo">
    <div>
      <h1>${esc(titulo)}</h1>
      <p class="suave">${esc(subtitulo)}</p>
    </div>
    <div>${acoes}</div>
  </header>`;

/* ------------------------------------------------------------------ telas -- */

// Landing pública
function telaInicio() {
  app.innerHTML = `
    <section class="landing-hero grade-tecnica">
      <div>
        ${marca()}
        <h1>Confirme a compatibilidade da peça antes de comprar.</h1>
        <p>
          Cadastre seus veículos, pesquise pela peça ou código e receba um
          diagnóstico técnico com grau de confiança e orientação de aplicação.
        </p>
        <a class="btn btn-primario" href="#/login">Entrar na plataforma</a>
      </div>
    </section>`;
}

// Login
function telaLogin() {
  app.innerHTML = `
    <section class="auth-tela grade-tecnica">
      <div class="auth-cartao">
        ${marca()}
        <h1>Entrar</h1>
        <p class="suave" style="margin-bottom:20px">Acesse sua conta para consultar peças.</p>
        <div id="erro"></div>
        <form id="form-login">
          <div class="campo">
            <label for="email">E-mail</label>
            <input id="email" type="email" autocomplete="email" placeholder="voce@empresa.com.br" required />
          </div>
          <div class="campo">
            <label for="senha">Senha</label>
            <div class="senha-wrap">
              <input id="senha" type="password" autocomplete="current-password" placeholder="Sua senha" required />
              <button type="button" data-acao="ver-senha">mostrar</button>
            </div>
          </div>
          <label class="checkbox" style="margin-bottom:16px">
            <input type="checkbox" id="lembrar" checked /> Manter conectado
          </label>
          <button class="btn btn-primario btn-bloco" type="submit">Entrar</button>
        </form>
        <div class="auth-rodape">
          <a href="#/recuperar-senha">Esqueci minha senha</a>
        </div>
      </div>
    </section>`;

  document.getElementById("form-login").addEventListener("submit", async (e) => {
    e.preventDefault();
    const erro = document.getElementById("erro");
    erro.innerHTML = "";
    const email = document.getElementById("email").value.trim();
    const senha = document.getElementById("senha").value;
    if (!email.includes("@")) return (erro.innerHTML = '<div class="alerta">Informe um e-mail válido.</div>');
    if (senha.length < 6)
      return (erro.innerHTML = '<div class="alerta">A senha deve ter no mínimo 6 caracteres.</div>');
    const botao = e.target.querySelector('button[type="submit"]');
    botao.disabled = true;
    botao.innerHTML = '<span class="carregando"></span> Entrando';
    try {
      await API.entrar(email, senha);
      location.hash = "#/dashboard";
    } catch (err) {
      erro.innerHTML = `<div class="alerta">${esc(err.message)}</div>`;
    } finally {
      botao.disabled = false;
      botao.textContent = "Entrar";
    }
  });
}

// Cadastro (sem marca, conforme padrão do projeto)
function telaCadastro() {
  app.innerHTML = `
    <section class="auth-tela grade-tecnica">
      <div class="auth-cartao">
        <h1>Criar conta</h1>
        <p class="suave" style="margin-bottom:20px">Preencha os dados para começar.</p>
        <div id="erro"></div>
        <form id="form-cadastro">
          <div class="campo"><label for="nome">Nome completo</label><input id="nome" required /></div>
          <div class="campo"><label for="email">E-mail</label><input id="email" type="email" required /></div>
          <div class="campo"><label for="telefone">Telefone</label><input id="telefone" placeholder="(00) 00000-0000" /></div>
          <div class="campo"><label for="senha">Senha</label><input id="senha" type="password" required /></div>
          <button class="btn btn-primario btn-bloco" type="submit">Cadastrar</button>
        </form>
        <div class="auth-rodape">Já tem conta? <a href="#/login">Entrar</a></div>
      </div>
    </section>`;

  document.getElementById("form-cadastro").addEventListener("submit", async (e) => {
    e.preventDefault();
    const erro = document.getElementById("erro");
    try {
      await API.cadastrar({
        nome: nome.value.trim(),
        email: email.value.trim(),
        telefone: telefone.value.trim(),
        senha: senha.value,
      });
      avisar("Conta criada com sucesso.", "ok");
      location.hash = "#/login";
    } catch (err) {
      erro.innerHTML = `<div class="alerta">${esc(err.message)}</div>`;
    }
  });
}

// Recuperação de senha
function telaRecuperar() {
  app.innerHTML = `
    <section class="auth-tela grade-tecnica">
      <div class="auth-cartao">
        ${marca()}
        <h1>Recuperar senha</h1>
        <p class="suave" style="margin-bottom:20px">Enviaremos um link de redefinição para o seu e-mail.</p>
        <div id="erro"></div>
        <form id="form-recuperar">
          <div class="campo"><label for="email">E-mail</label><input id="email" type="email" required /></div>
          <button class="btn btn-primario btn-bloco" type="submit">Enviar link</button>
        </form>
        <div class="auth-rodape"><a href="#/login">Voltar para o login</a></div>
      </div>
    </section>`;

  document.getElementById("form-recuperar").addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      await API.recuperarSenha(document.getElementById("email").value.trim());
      avisar("Link enviado. Confira seu e-mail.", "ok");
    } catch (err) {
      document.getElementById("erro").innerHTML = `<div class="alerta">${esc(err.message)}</div>`;
    }
  });
}

// Painel
async function telaDashboard() {
  app.innerHTML = shell("#/dashboard", cabecalho("Painel", "Visão geral da sua operação") + carregando());
  const [resumo, veiculos, historico, manutencoes] = await Promise.all([
    API.obterResumo(),
    API.listarVeiculos(),
    API.listarHistorico(),
    API.listarManutencoes(),
  ]);

  const metrica = (rotulo, valor) =>
    `<div class="cartao metrica"><div class="rotulo">${rotulo}</div><div class="valor">${valor}</div></div>`;

  const listaVeiculos = veiculos.length
    ? `<div class="grade grade-3">${veiculos
        .slice(0, 3)
        .map(
          (v) => `<div class="cartao">
            <div class="cartao-cabecalho">
              <h3>${esc(v.marca)} ${esc(v.modelo)}</h3>
              ${v.principal ? '<span class="selo selo-principal">Principal</span>' : ""}
            </div>
            <p class="suave mono">${esc(v.ano)} · ${esc(v.motor || "—")} · ${esc(v.placa || "sem placa")}</p>
          </div>`,
        )
        .join("")}</div>`
    : estadoVazio(
        "Nenhum veículo cadastrado",
        "Cadastre um veículo para começar a consultar peças.",
        '<a class="btn btn-primario" href="#/veiculos">Cadastrar veículo</a>',
      );

  const listaHistorico = historico.length
    ? `<div class="cartao tabela-rolagem"><table>
        <thead><tr><th>Data</th><th>Veículo</th><th>Peça</th><th>Resultado</th></tr></thead>
        <tbody>${historico
          .slice(0, 5)
          .map(
            (h) => `<tr><td class="mono">${formatarData(h.data)}</td><td>${esc(h.veiculoLabel)}</td>
              <td>${esc(h.pecaNome)}</td><td>${seloResultado(h.resultado)}</td></tr>`,
          )
          .join("")}</tbody></table></div>`
    : estadoVazio("Sem verificações", "Suas consultas de compatibilidade aparecerão aqui.");

  const listaManutencao = manutencoes.length
    ? `<div class="grade grade-3">${manutencoes
        .slice(0, 3)
        .map(
          (m) => `<div class="cartao">
            <div class="cartao-cabecalho"><h3>${esc(m.tipo)}</h3><span class="selo">${esc(m.status)}</span></div>
            <p class="suave">${esc(m.veiculoLabel)} · ${formatarData(m.dataPrevista)}</p>
          </div>`,
        )
        .join("")}</div>`
    : estadoVazio("Nenhuma manutenção registrada", "Programe revisões para receber lembretes.");

  app.innerHTML = shell(
    "#/dashboard",
    cabecalho("Painel", "Visão geral da sua operação") +
      `<div class="grade grade-4">
        ${metrica("Veículos", resumo.veiculos ?? veiculos.length)}
        ${metrica("Verificações", resumo.verificacoes ?? historico.length)}
        ${metrica("Compatíveis", resumo.compativeis ?? 0)}
        ${metrica("Manutenções pendentes", resumo.manutencoesPendentes ?? 0)}
      </div>
      <section class="secao"><h2>Meus veículos</h2>${listaVeiculos}</section>
      <section class="secao"><h2>Últimas verificações</h2>${listaHistorico}</section>
      <section class="secao"><h2>Manutenção preventiva</h2>${listaManutencao}</section>`,
  );
}

// Consulta de peça (4 passos)
async function telaVerificar() {
  const [veiculos, categorias] = await Promise.all([API.listarVeiculos(), API.listarCategorias()]);

  app.innerHTML = shell(
    "#/verificar",
    cabecalho("Consultar peça", "Selecione o veículo, escolha a peça e verifique a aplicação") +
      `<ol class="passos" id="passos">
        <li class="passo" data-passo="1">1. Veículo</li><li class="passo" data-passo="2">2. Peça</li>
        <li class="passo" data-passo="3">3. Verificação</li><li class="passo" data-passo="4">4. Resultado</li>
      </ol>
      <div class="cartao">
        <div class="linha-campos">
          <div class="campo">
            <label for="veiculo">Veículo</label>
            <select id="veiculo">
              <option value="">Selecione um veículo</option>
              ${veiculos
                .map((v) => `<option value="${esc(v.id)}">${esc(v.marca)} ${esc(v.modelo)} ${esc(v.ano)}</option>`)
                .join("")}
            </select>
          </div>
          <div class="campo">
            <label for="categoria">Categoria</label>
            <select id="categoria"><option value="">Todas as categorias</option>
              ${categorias.map((c) => `<option>${esc(c)}</option>`).join("")}</select>
          </div>
          <div class="campo">
            <label for="termo">Peça ou código</label>
            <input id="termo" placeholder="Ex.: pastilha de freio ou 45022-XYZ" />
          </div>
        </div>
        <button class="btn btn-primario" data-acao="buscar">Buscar peças</button>
      </div>
      <section class="secao" id="lista-pecas">
        ${estadoVazio("Nenhuma busca realizada", "Informe um termo ou categoria para listar as peças.")}
      </section>
      <section class="secao" id="resultado"></section>`,
  );

  // Passos ficam verdes conforme cada requisito é atendido
  function atualizarPassos(estado = {}) {
    const veiculoOk = !!document.getElementById("veiculo").value;
    const pecaOk =
      !!document.getElementById("termo").value.trim() || !!document.getElementById("categoria").value;
    const concluidos = {
      1: veiculoOk,
      2: pecaOk,
      3: !!estado.verificado,
      4: !!estado.comResultado,
    };
    const atual = concluidos[3] ? 4 : concluidos[2] ? 3 : concluidos[1] ? 2 : 1;
    app.querySelectorAll("#passos .passo").forEach((el) => {
      const n = Number(el.dataset.passo);
      el.classList.toggle("concluido", !!concluidos[n]);
      el.classList.toggle("ativo", !concluidos[n] && n === atual);
    });
  }
  atualizarPassos();
  ["veiculo", "categoria", "termo"].forEach((id) => {
    const el = document.getElementById(id);
    el.addEventListener("input", () => atualizarPassos());
    el.addEventListener("change", () => atualizarPassos());
  });

  app.querySelector('[data-acao="buscar"]').addEventListener("click", async () => {
    const alvo = document.getElementById("lista-pecas");
    alvo.innerHTML = carregando();
    try {
      const pecas = await API.buscarPecas({
        termo: document.getElementById("termo").value.trim(),
        categoria: document.getElementById("categoria").value,
      });
      alvo.innerHTML = pecas.length
        ? `<div class="grade grade-2">${pecas
            .map(
              (p) => `<article class="cartao">
                <div class="cartao-cabecalho">
                  <h3>${esc(p.nome)}</h3><span class="selo">${esc(p.categoria)}</span>
                </div>
                <p class="suave mono">${esc(p.codigo)} · OEM ${esc(p.oem || "—")} · ${esc(p.fabricante || "—")}</p>
                <p style="margin:10px 0 12px">${esc(p.descricao || "")}</p>
                <p class="suave">Valor base do investimento: <strong>${formatarValor(p.valorBase)}</strong>
                  <br /><small>Valor apenas de referência de mercado.</small></p>
                <button class="btn btn-primario btn-sm" style="margin-top:12px"
                  data-verificar="${esc(p.id)}">Verificar compatibilidade</button>
              </article>`,
            )
            .join("")}</div>`
        : estadoVazio("Nenhuma peça encontrada", "Revise o termo pesquisado ou tente outra categoria.");
      atualizarPassos();
    } catch (err) {
      alvo.innerHTML = `<div class="alerta">${esc(err.message)}</div>`;
    }
  });

  app.addEventListener("click", async (e) => {
    const botao = e.target.closest("[data-verificar]");
    if (!botao) return;
    const veiculoId = document.getElementById("veiculo").value;
    if (!veiculoId) return avisar("Selecione um veículo antes de verificar.");
    const alvo = document.getElementById("resultado");
    alvo.innerHTML = '<div class="cartao"><span class="carregando"></span> Verificando…</div>';
    try {
      const a = await API.verificarCompatibilidade(veiculoId, botao.dataset.verificar);
      alvo.innerHTML = `
        <div class="cartao">
          <div class="cartao-cabecalho">${seloResultado(a.resultado)}
            <span class="mono">${esc(a.grau ?? 0)}% de confiança</span></div>
          <div class="medidor"><span class="${(Number(a.grau) || 0) > 70 ? "alto" : ""}"
            style="width:${Number(a.grau) || 0}%"></span></div>
          <p style="margin-top:14px"><strong>Motivo:</strong> ${esc(a.motivo || "—")}</p>
          <p class="suave" style="margin-top:6px"><strong>Orientação:</strong> ${esc(a.orientacao || "—")}</p>
        </div>`;
      atualizarPassos({ verificado: true, comResultado: true });
    } catch (err) {
      alvo.innerHTML = `<div class="alerta">${esc(err.message)}</div>`;
    }
  });
}

// Meus veículos
function formularioVeiculo(v = {}) {
  return `
  <form id="form-veiculo" style="margin-top:14px">
    <div class="linha-campos">
      <div class="campo"><label>Tipo</label>
        <select name="tipo">${TIPOS_VEICULO.map(
          (t) => `<option ${v.tipo === t ? "selected" : ""}>${t}</option>`,
        ).join("")}</select></div>
      <div class="campo"><label>Marca</label><input name="marca" value="${esc(v.marca || "")}" required /></div>
      <div class="campo"><label>Modelo</label><input name="modelo" value="${esc(v.modelo || "")}" required /></div>
      <div class="campo"><label>Ano</label><input name="ano" type="number" value="${esc(v.ano || "")}" required /></div>
      <div class="campo"><label>Versão</label><input name="versao" value="${esc(v.versao || "")}" /></div>
      <div class="campo"><label>Motor</label><input name="motor" value="${esc(v.motor || "")}" /></div>
      <div class="campo"><label>Combustível</label>
        <select name="combustivel">${COMBUSTIVEIS.map(
          (c) => `<option ${v.combustivel === c ? "selected" : ""}>${c}</option>`,
        ).join("")}</select></div>
      <div class="campo"><label>Placa</label><input name="placa" value="${esc(v.placa || "")}" /></div>
    </div>
    <label class="checkbox"><input type="checkbox" name="principal" ${v.principal ? "checked" : ""} />
      Definir como veículo principal</label>
    <div class="modal-acoes">
      <button type="button" class="btn btn-secundario" data-acao="fechar-modal">Cancelar</button>
      <button type="submit" class="btn btn-primario">Salvar veículo</button>
    </div>
  </form>`;
}

async function telaVeiculos() {
  app.innerHTML = shell("#/veiculos", cabecalho("Meus veículos", "Gerencie sua garagem") + carregando());
  const veiculos = await API.listarVeiculos();

  const acoes = '<button class="btn btn-primario" data-acao="novo-veiculo">Adicionar veículo</button>';
  const lista = veiculos.length
    ? `<div class="grade grade-3">${veiculos
        .map(
          (v) => `<article class="cartao">
            <div class="cartao-cabecalho">
              <h3>${esc(v.marca)} ${esc(v.modelo)}</h3>
              ${v.principal ? '<span class="selo selo-principal">Principal</span>' : ""}
            </div>
            <p class="suave mono">${esc(v.tipo || "—")} · ${esc(v.ano || "—")} · ${esc(v.motor || "—")}</p>
            <p class="suave mono">${esc(v.placa || "sem placa")} · ${esc(v.combustivel || "—")}</p>
            <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap">
              <button class="btn btn-secundario btn-sm" data-editar="${esc(v.id)}">Editar</button>
              <button class="btn btn-fantasma btn-sm" data-principal="${esc(v.id)}">Tornar principal</button>
              <button class="btn btn-perigo btn-sm" data-excluir="${esc(v.id)}">Excluir</button>
            </div>
          </article>`,
        )
        .join("")}</div>`
    : estadoVazio(
        "Sua garagem está vazia",
        "Cadastre o primeiro veículo para consultar peças compatíveis.",
        '<button class="btn btn-primario" data-acao="novo-veiculo">Adicionar veículo</button>',
      );

  app.innerHTML = shell("#/veiculos", cabecalho("Meus veículos", "Gerencie sua garagem", acoes) + lista);

  app.addEventListener("click", async (e) => {
    const alvo = e.target;
    if (alvo.closest('[data-acao="novo-veiculo"]')) {
      abrirModal("Novo veículo", formularioVeiculo());
      ligarFormularioVeiculo();
    }
    const editar = alvo.closest("[data-editar]");
    if (editar) {
      const v = veiculos.find((x) => String(x.id) === editar.dataset.editar) || {};
      abrirModal("Editar veículo", formularioVeiculo(v));
      ligarFormularioVeiculo(v.id);
    }
    const principal = alvo.closest("[data-principal]");
    if (principal) {
      try {
        await API.definirVeiculoPrincipal(principal.dataset.principal);
        avisar("Veículo principal atualizado.", "ok");
        telaVeiculos();
      } catch (err) {
        avisar(err.message);
      }
    }
    const excluir = alvo.closest("[data-excluir]");
    if (excluir && confirm("Excluir este veículo?")) {
      try {
        await API.excluirVeiculo(excluir.dataset.excluir);
        avisar("Veículo excluído.", "ok");
        telaVeiculos();
      } catch (err) {
        avisar(err.message);
      }
    }
  });
}

function ligarFormularioVeiculo(id) {
  document.getElementById("form-veiculo").addEventListener("submit", async (e) => {
    e.preventDefault();
    const dados = Object.fromEntries(new FormData(e.target).entries());
    try {
      await API.salvarVeiculo({
        ...dados,
        id,
        ano: Number(dados.ano),
        principal: Boolean(dados.principal),
      });
      fecharModal();
      avisar("Veículo salvo.", "ok");
      telaVeiculos();
    } catch (err) {
      avisar(err.message);
    }
  });
}

// Manutenção preventiva
async function telaManutencao() {
  app.innerHTML = shell("#/manutencao", cabecalho("Manutenção preventiva", "Programe e acompanhe revisões") + carregando());
  const [manutencoes, veiculos] = await Promise.all([API.listarManutencoes(), API.listarVeiculos()]);

  const acoes = '<button class="btn btn-primario" data-acao="nova-manutencao">Nova manutenção</button>';
  const lista = manutencoes.length
    ? `<div class="cartao tabela-rolagem"><table>
        <thead><tr><th>Veículo</th><th>Serviço</th><th>Data prevista</th><th>KM</th><th>Status</th><th></th></tr></thead>
        <tbody>${manutencoes
          .map(
            (m) => `<tr>
              <td>${esc(m.veiculoLabel)}</td><td>${esc(m.tipo)}</td>
              <td class="mono">${formatarData(m.dataPrevista)}</td>
              <td class="mono">${esc(m.kmPrevisto ?? "—")}</td>
              <td><span class="selo">${esc(m.status)}</span></td>
              <td><button class="btn btn-perigo btn-sm" data-remover-manut="${esc(m.id)}">Excluir</button></td>
            </tr>`,
          )
          .join("")}</tbody></table></div>`
    : estadoVazio(
        "Nenhuma manutenção programada",
        "Cadastre revisões, trocas de óleo e inspeções para não perder prazos.",
        '<button class="btn btn-primario" data-acao="nova-manutencao">Nova manutenção</button>',
      );

  app.innerHTML = shell(
    "#/manutencao",
    cabecalho("Manutenção preventiva", "Programe e acompanhe revisões", acoes) + lista,
  );

  app.addEventListener("click", async (e) => {
    if (e.target.closest('[data-acao="nova-manutencao"]')) {
      abrirModal(
        "Nova manutenção",
        `<form id="form-manutencao" style="margin-top:14px">
          <div class="campo"><label>Veículo</label>
            <select name="veiculoId" required>
              <option value="">Selecione</option>
              ${veiculos.map((v) => `<option value="${esc(v.id)}">${esc(v.marca)} ${esc(v.modelo)}</option>`).join("")}
            </select></div>
          <div class="campo"><label>Serviço</label><input name="tipo" required /></div>
          <div class="linha-campos">
            <div class="campo"><label>Data prevista</label><input name="dataPrevista" type="date" required /></div>
            <div class="campo"><label>KM previsto</label><input name="kmPrevisto" type="number" /></div>
            <div class="campo"><label>Status</label>
              <select name="status">${STATUS_MANUTENCAO.map((s) => `<option>${s}</option>`).join("")}</select></div>
          </div>
          <div class="campo"><label>Observações</label><textarea name="observacoes" rows="3"></textarea></div>
          <div class="modal-acoes">
            <button type="button" class="btn btn-secundario" data-acao="fechar-modal">Cancelar</button>
            <button type="submit" class="btn btn-primario">Salvar</button>
          </div>
        </form>`,
      );
      document.getElementById("form-manutencao").addEventListener("submit", async (ev) => {
        ev.preventDefault();
        const dados = Object.fromEntries(new FormData(ev.target).entries());
        try {
          await API.salvarManutencao(dados);
          fecharModal();
          avisar("Manutenção salva.", "ok");
          telaManutencao();
        } catch (err) {
          avisar(err.message);
        }
      });
    }
    const remover = e.target.closest("[data-remover-manut]");
    if (remover && confirm("Excluir esta manutenção?")) {
      try {
        await API.excluirManutencao(remover.dataset.removerManut);
        telaManutencao();
      } catch (err) {
        avisar(err.message);
      }
    }
  });
}

// Histórico
async function telaHistorico() {
  const filtros = `
    <div class="cartao">
      <div class="linha-campos">
        <div class="campo"><label>Resultado</label>
          <select id="f-resultado"><option value="">Todos</option>
            <option value="COMPATIVEL">Compatível</option>
            <option value="INCOMPATIVEL">Não compatível</option>
            <option value="VERIFICAR">Não confirmada</option></select></div>
        <div class="campo"><label>Tipo de veículo</label>
          <select id="f-tipo"><option value="">Todos</option>
            ${TIPOS_VEICULO.map((t) => `<option>${t}</option>`).join("")}</select></div>
        <div class="campo"><label>Buscar</label><input id="f-termo" placeholder="Peça ou código" /></div>
      </div>
      <button class="btn btn-secundario btn-sm" data-acao="filtrar">Aplicar filtros</button>
      <button class="btn btn-fantasma btn-sm" data-acao="limpar-historico">Limpar histórico</button>
    </div>`;

  async function render() {
    const alvo = document.getElementById("lista-historico");
    alvo.innerHTML = carregando();
    const itens = await API.listarHistorico({
      resultado: document.getElementById("f-resultado").value,
      tipoVeiculo: document.getElementById("f-tipo").value,
      termo: document.getElementById("f-termo").value.trim(),
    });
    alvo.innerHTML = itens.length
      ? `<div class="cartao tabela-rolagem"><table>
          <thead><tr><th>Data</th><th>Veículo</th><th>Peça</th><th>Categoria</th><th>Resultado</th></tr></thead>
          <tbody>${itens
            .map(
              (h) => `<tr><td class="mono">${formatarData(h.data)}</td><td>${esc(h.veiculoLabel)}</td>
                <td>${esc(h.pecaNome)}<br /><small class="suave mono">${esc(h.pecaCodigo || "")}</small></td>
                <td>${esc(h.categoria || "—")}</td><td>${seloResultado(h.resultado)}</td></tr>`,
            )
            .join("")}</tbody></table></div>`
      : estadoVazio("Nenhum registro encontrado", "As verificações realizadas ficarão listadas aqui.");
  }

  app.innerHTML = shell(
    "#/historico",
    cabecalho("Histórico", "Todas as verificações realizadas") +
      filtros +
      '<section class="secao" id="lista-historico"></section>',
  );
  render();

  app.addEventListener("click", async (e) => {
    if (e.target.closest('[data-acao="filtrar"]')) render();
    if (e.target.closest('[data-acao="limpar-historico"]') && confirm("Apagar todo o histórico?")) {
      try {
        await API.limparHistorico();
        render();
      } catch (err) {
        avisar(err.message);
      }
    }
  });
}

// Perfil
async function telaPerfil() {
  const perfil = (await API.obterPerfil()) || { nome: "", email: "", telefone: "" };
  app.innerHTML = shell(
    "#/perfil",
    cabecalho("Perfil", "Dados da sua conta") +
      `<div class="cartao" style="max-width:560px">
        <form id="form-perfil">
          <div class="campo"><label>Nome</label><input name="nome" value="${esc(perfil.nome)}" /></div>
          <div class="campo"><label>E-mail</label><input name="email" type="email" value="${esc(perfil.email)}" /></div>
          <div class="campo"><label>Telefone</label><input name="telefone" value="${esc(perfil.telefone)}" /></div>
          <button class="btn btn-primario" type="submit">Salvar alterações</button>
        </form>
      </div>`,
  );
  document.getElementById("form-perfil").addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      await API.salvarPerfil(Object.fromEntries(new FormData(e.target).entries()));
      avisar("Perfil atualizado.", "ok");
    } catch (err) {
      avisar(err.message);
    }
  });
}

// Configurações
function telaConfiguracoes() {
  const temaClaro = localStorage.getItem("partlogic.tema") === "claro";
  app.innerHTML = shell(
    "#/configuracoes",
    cabecalho("Configurações", "Aparência, idioma e suporte") +
      `<div class="grade grade-2">
        <div class="cartao">
          <h2>Aparência</h2>
          <label class="checkbox" style="margin-top:12px">
            <input type="checkbox" id="tema" ${temaClaro ? "checked" : ""} /> Usar tema claro
          </label>
        </div>
        <div class="cartao">
          <h2>Idioma</h2>
          <div class="campo" style="margin-top:12px">
            <select id="idioma">
              <option value="pt">Português (Brasil)</option>
              <option value="en">English</option>
              <option value="es">Español</option>
              <option value="fr">Français</option>
              <option value="de">Deutsch</option>
              <option value="zh">中文</option>
              <option value="ja">日本語</option>
            </select>
          </div>
        </div>
      </div>
      <section class="secao">
        <h2>Suporte</h2>
        <div class="cartao">
          <details class="acordeao"><summary>Como funciona a verificação de compatibilidade?</summary>
            <p>O sistema compara marca, modelo, ano e motorização do veículo com as regras de aplicação da peça.</p></details>
          <details class="acordeao"><summary>O que significa "não confirmada"?</summary>
            <p>Há indícios de aplicação, mas algum dado (ano ou motor) está no limite da faixa registrada.</p></details>
          <details class="acordeao"><summary>O valor exibido é o preço final?</summary>
            <p>Não. O valor base do investimento é apenas uma referência de mercado.</p></details>
        </div>
      </section>`,
  );

  document.getElementById("tema").addEventListener("change", async (e) => {
    const tema = e.target.checked ? "claro" : "escuro";
    localStorage.setItem("partlogic.tema", tema);
    aplicarTema();
    await API.salvarPreferencias({ tema });
  });
  document.getElementById("idioma").value = localStorage.getItem("partlogic.idioma") || "pt";
  document.getElementById("idioma").addEventListener("change", async (e) => {
    localStorage.setItem("partlogic.idioma", e.target.value);
    await API.salvarPreferencias({ idioma: e.target.value });
    avisar("Idioma atualizado.", "ok");
  });
}

function aplicarTema() {
  document.body.classList.toggle("tema-claro", localStorage.getItem("partlogic.tema") === "claro");
}

/* ----------------------------------------------------------------- rotas -- */
const ROTAS = {
  "#/": telaInicio,
  "#/login": telaLogin,
  "#/cadastro": telaCadastro,
  "#/recuperar-senha": telaRecuperar,
  "#/dashboard": telaDashboard,
  "#/verificar": telaVerificar,
  "#/veiculos": telaVeiculos,
  "#/manutencao": telaManutencao,
  "#/historico": telaHistorico,
  "#/perfil": telaPerfil,
  "#/configuracoes": telaConfiguracoes,
};

const PUBLICAS = ["#/", "#/login", "#/cadastro", "#/recuperar-senha"];

async function navegar() {
  const rota = location.hash || "#/";
  const render = ROTAS[rota] || telaInicio;

  // Proteção de rota: descomente após integrar a autenticação real.
  // if (!PUBLICAS.includes(rota) && !API.autenticado()) return (location.hash = "#/login");

  try {
    await render();
  } catch (err) {
    app.innerHTML = `<main class="conteudo"><div class="alerta">${esc(err.message)}</div></main>`;
  }
  window.scrollTo(0, 0);
}

document.addEventListener("click", (e) => {
  if (e.target.closest('[data-acao="fechar-modal"]')) fecharModal();
  if (e.target.closest('[data-acao="ver-senha"]')) {
    const campo = document.getElementById("senha");
    campo.type = campo.type === "password" ? "text" : "password";
  }
  if (e.target.closest('[data-acao="sair"]')) {
    API.sair();
    location.hash = "#/login";
  }
});

window.addEventListener("hashchange", navegar);
aplicarTema();
navegar();
