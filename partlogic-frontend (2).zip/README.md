# PartLogic — Front-end estático (HTML + CSS + JS)

Versão do site em HTML, CSS e JavaScript puro, **sem dados de demonstração**,
pronta para você abrir no VS Code e ligar ao seu backend.

## Estrutura

```
partlogic-frontend/
├── index.html        Estrutura da página (SPA por hash) + metatags
├── css/styles.css    Design system completo (tema escuro + tema claro)
└── js/
    ├── api.js        ÚNICO arquivo a editar para integrar o backend
    └── app.js        Telas, roteamento, formulários e estados de UI
```

## Como rodar

Abra `index.html` no navegador, ou sirva a pasta:

```bash
npx serve .
# ou
python3 -m http.server 5173
```

## Telas incluídas

`#/` landing · `#/login` · `#/cadastro` · `#/recuperar-senha` · `#/dashboard` ·
`#/verificar` (consulta em 4 passos com grau de confiança) · `#/veiculos` (CRUD) ·
`#/manutencao` (preventiva) · `#/historico` (filtros) · `#/perfil` ·
`#/configuracoes` (tema, idioma, FAQ).

Todas já trazem estado vazio, estado de carregamento e mensagens de erro.

## Integração do backend

Edite apenas `js/api.js`:

1. Ajuste `BASE_URL` para a URL da sua API.
2. Em cada função, descomente a linha `requisicao(...)` e remova o `throw` /
   o retorno vazio.
3. O login deve salvar o token em `localStorage` (`partlogic.token`); o wrapper
   `requisicao()` já envia `Authorization: Bearer <token>`.
4. Em `js/app.js`, na função `navegar()`, descomente a linha de proteção de
   rota para exigir autenticação nas telas internas.

### Endpoints sugeridos

| Método | Rota | Uso |
| --- | --- | --- |
| POST | `/auth/login` | login (retorna `{ token, usuario }`) |
| POST | `/auth/registro` | cadastro |
| POST | `/auth/recuperar` | recuperação de senha |
| GET/PUT | `/perfil` | dados da conta |
| GET/POST | `/veiculos` | listar / criar |
| PUT/DELETE | `/veiculos/:id` | editar / excluir |
| PATCH | `/veiculos/:id/principal` | definir principal |
| GET | `/pecas?termo=&categoria=` | busca de peças |
| GET | `/pecas/categorias` | categorias |
| POST | `/verificacoes` | verificar compatibilidade (retorna avaliação) |
| GET/DELETE | `/verificacoes` | histórico / limpar |
| GET/POST | `/manutencoes` | manutenção preventiva |
| PUT/PATCH/DELETE | `/manutencoes/:id` | editar / status / excluir |
| GET | `/dashboard/resumo` | métricas do painel |
| PUT | `/preferencias` | tema, idioma, notificações |

Os formatos de cada objeto (`Veiculo`, `Peca`, `Verificacao`, `Avaliacao`,
`Manutencao`) estão documentados no topo de `js/api.js`.

## Identidade visual

Tokens em `css/styles.css`: preto `#0B0B0B`, grafite `#121212` / `#1A1A1A`,
vermelho `#E03333` (`--primaria`) e `#C22626` (`--primaria-forte`).
Fontes: Plus Jakarta Sans (texto) e JetBrains Mono (dados técnicos).
