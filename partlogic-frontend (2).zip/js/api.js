/* ==========================================================================
   PartLogic — Camada de integração com o backend
   --------------------------------------------------------------------------
   Este é o ÚNICO arquivo que você precisa editar para ligar o front ao seu
   backend. Todas as funções já retornam a forma de dado que a interface espera.
   Substitua os "TODO" pelas suas chamadas fetch reais.

   Formatos esperados:
   Usuario     { nome, email, telefone }
   Veiculo     { id, tipo, marca, modelo, ano, versao, motor, combustivel,
                 placa, principal }
   Peca        { id, nome, codigo, oem, fabricante, categoria, descricao,
                 valorBase, specs: [{ label, valor }] }
   Verificacao { id, data (ISO), veiculoId, veiculoLabel, veiculoTipo, pecaNome,
                 pecaCodigo, categoria, resultado: 'COMPATIVEL'|'INCOMPATIVEL'|
                 'VERIFICAR', motivo }
   Avaliacao   { resultado, motivo, orientacao, grau (0-100) }
   Manutencao  { id, veiculoId, veiculoLabel, tipo, dataPrevista (YYYY-MM-DD),
                 kmPrevisto, status: 'Próxima'|'Agendada'|'Realizada'|'Atrasada',
                 observacoes }
   ========================================================================== */

const API = (() => {
  /** Base da sua API. Ex.: "http://localhost:3000/api" */
  const BASE_URL = "/api";

  /** Token guardado no navegador após o login. */
  const CHAVE_TOKEN = "partlogic.token";

  function token() {
    return localStorage.getItem(CHAVE_TOKEN) || "";
  }

  /** Wrapper de fetch com JSON + Authorization. */
  async function requisicao(caminho, opcoes = {}) {
    const resposta = await fetch(`${BASE_URL}${caminho}`, {
      ...opcoes,
      headers: {
        "Content-Type": "application/json",
        ...(token() ? { Authorization: `Bearer ${token()}` } : {}),
        ...(opcoes.headers || {}),
      },
      body: opcoes.body ? JSON.stringify(opcoes.body) : undefined,
    });
    if (!resposta.ok) {
      let mensagem = `Erro ${resposta.status}`;
      try {
        const corpo = await resposta.json();
        mensagem = corpo.message || corpo.erro || mensagem;
      } catch (_) {}
      throw new Error(mensagem);
    }
    return resposta.status === 204 ? null : resposta.json();
  }

  return {
    BASE_URL,
    requisicao,

    /* ------------------------------------------------------- autenticação -- */
    async entrar(email, senha) {
      // TODO: return requisicao("/auth/login", { method: "POST", body: { email, senha } })
      //       .then((r) => { localStorage.setItem(CHAVE_TOKEN, r.token); return r.usuario; });
      throw new Error("Integre API.entrar() com o seu backend.");
    },

    async cadastrar(dados) {
      // dados = { nome, email, telefone, senha }
      // TODO: return requisicao("/auth/registro", { method: "POST", body: dados });
      throw new Error("Integre API.cadastrar() com o seu backend.");
    },

    async recuperarSenha(email) {
      // TODO: return requisicao("/auth/recuperar", { method: "POST", body: { email } });
      throw new Error("Integre API.recuperarSenha() com o seu backend.");
    },

    sair() {
      localStorage.removeItem(CHAVE_TOKEN);
      // TODO (opcional): requisicao("/auth/logout", { method: "POST" });
    },

    autenticado() {
      return Boolean(token());
    },

    /* ------------------------------------------------------------ perfil -- */
    async obterPerfil() {
      // TODO: return requisicao("/perfil");
      return null;
    },

    async salvarPerfil(dados) {
      // TODO: return requisicao("/perfil", { method: "PUT", body: dados });
      throw new Error("Integre API.salvarPerfil() com o seu backend.");
    },

    /* ---------------------------------------------------------- veículos -- */
    async listarVeiculos() {
      // TODO: return requisicao("/veiculos");
      return [];
    },

    async obterVeiculo(id) {
      // TODO: return requisicao(`/veiculos/${id}`);
      return null;
    },

    async salvarVeiculo(veiculo) {
      // TODO: return veiculo.id
      //   ? requisicao(`/veiculos/${veiculo.id}`, { method: "PUT", body: veiculo })
      //   : requisicao("/veiculos", { method: "POST", body: veiculo });
      throw new Error("Integre API.salvarVeiculo() com o seu backend.");
    },

    async excluirVeiculo(id) {
      // TODO: return requisicao(`/veiculos/${id}`, { method: "DELETE" });
      throw new Error("Integre API.excluirVeiculo() com o seu backend.");
    },

    async definirVeiculoPrincipal(id) {
      // TODO: return requisicao(`/veiculos/${id}/principal`, { method: "PATCH" });
      throw new Error("Integre API.definirVeiculoPrincipal() com o seu backend.");
    },

    /* -------------------------------------------------------------- peças -- */
    async buscarPecas({ termo = "", categoria = "", tipoVeiculo = "" } = {}) {
      // TODO: const q = new URLSearchParams({ termo, categoria, tipoVeiculo });
      //       return requisicao(`/pecas?${q}`);
      return [];
    },

    async listarCategorias() {
      // TODO: return requisicao("/pecas/categorias");
      return ["Filtros", "Freios", "Suspensão", "Motor", "Elétrica", "Transmissão"];
    },

    /* ------------------------------------------------- verificação/consulta */
    async verificarCompatibilidade(veiculoId, pecaId) {
      // Deve retornar Avaliacao: { resultado, motivo, orientacao, grau }
      // TODO: return requisicao("/verificacoes", {
      //   method: "POST", body: { veiculoId, pecaId },
      // });
      throw new Error("Integre API.verificarCompatibilidade() com o seu backend.");
    },

    async listarHistorico({ resultado = "", tipoVeiculo = "", termo = "" } = {}) {
      // TODO: const q = new URLSearchParams({ resultado, tipoVeiculo, termo });
      //       return requisicao(`/verificacoes?${q}`);
      return [];
    },

    async limparHistorico() {
      // TODO: return requisicao("/verificacoes", { method: "DELETE" });
      throw new Error("Integre API.limparHistorico() com o seu backend.");
    },

    /* -------------------------------------------------------- manutenções -- */
    async listarManutencoes({ status = "" } = {}) {
      // TODO: return requisicao(`/manutencoes?status=${status}`);
      return [];
    },

    async salvarManutencao(manutencao) {
      // TODO: return manutencao.id
      //   ? requisicao(`/manutencoes/${manutencao.id}`, { method: "PUT", body: manutencao })
      //   : requisicao("/manutencoes", { method: "POST", body: manutencao });
      throw new Error("Integre API.salvarManutencao() com o seu backend.");
    },

    async atualizarStatusManutencao(id, status) {
      // TODO: return requisicao(`/manutencoes/${id}/status`, { method: "PATCH", body: { status } });
      throw new Error("Integre API.atualizarStatusManutencao() com o seu backend.");
    },

    async excluirManutencao(id) {
      // TODO: return requisicao(`/manutencoes/${id}`, { method: "DELETE" });
      throw new Error("Integre API.excluirManutencao() com o seu backend.");
    },

    /* ---------------------------------------------------------- dashboard -- */
    async obterResumo() {
      // TODO: return requisicao("/dashboard/resumo");
      return { veiculos: 0, verificacoes: 0, compativeis: 0, manutencoesPendentes: 0 };
    },

    /* -------------------------------------------------------- preferências -- */
    async salvarPreferencias(prefs) {
      // prefs = { tema: 'escuro'|'claro', idioma: 'pt', notificacoes: boolean }
      // TODO: return requisicao("/preferencias", { method: "PUT", body: prefs });
      return prefs;
    },
  };
})();
